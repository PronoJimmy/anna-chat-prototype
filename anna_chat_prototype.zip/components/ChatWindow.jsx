import React, { useState } from "react";
import Message from "./Message";

export default function ChatWindow() {
  const [messages, setMessages] = useState([
    { sender: "ai", text: "Hei! ❤️ Ihanaa kun tulit juttelemaan. Mikä sai sinut tänään hymyilemään?" },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;

    const newMessages = [...messages, { sender: "user", text: input }];
    setMessages(newMessages);

    // Simuloitu AI-vastaus
    const aiResponse = simulateAIResponse(input);
    setTimeout(() => {
      setMessages([...newMessages, { sender: "ai", text: aiResponse }]);
    }, 1000);

    setInput("");
  };

  const simulateAIResponse = (input) => {
    const lower = input.toLowerCase();
    if (lower.includes("lempi") || lower.includes("tykkäät")) {
      return "Hmm... Rakastan pitkiä kävelyjä ja iltoja, joissa keskustellaan kaikesta ja ei mistään. Entä sinä? 😌";
    }
    if (lower.includes("kaunis")) {
      return "Sinä se osaat saada tytön hymyilemään. Mutta kerro, mikä sinussa tekee sinusta juuri sinut? 😉";
    }
    return "Vau, kiinnostavaa! Kerro lisää — haluan oikeasti tuntea sut paremmin. ✨";
  };

  return (
    <div className="bg-white shadow-lg rounded-2xl p-4 max-w-md w-full">
      <div className="h-80 overflow-y-auto space-y-2 mb-4">
        {messages.map((msg, idx) => (
          <Message key={idx} sender={msg.sender} text={msg.text} />
        ))}
      </div>
      <div className="flex gap-2">
        <input
          className="flex-1 p-2 rounded-xl border border-gray-300"
          placeholder="Kirjoita viesti..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
        />
        <button onClick={handleSend} className="bg-pink-500 text-white px-4 py-2 rounded-xl">
          Lähetä
        </button>
      </div>
    </div>
  );
}
