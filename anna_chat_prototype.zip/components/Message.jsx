import React from "react";

export default function Message({ sender, text }) {
  const isUser = sender === "user";
  return (
    <div className={\`flex \${isUser ? "justify-end" : "justify-start"}\`}>
      <div
        className={\`p-3 rounded-xl max-w-[70%] \${isUser ? "bg-pink-200 text-right" : "bg-gray-100"}\`}
      >
        {text}
      </div>
    </div>
  );
}
