import React from "react";

export default function ProfileCard() {
  return (
    <div className="bg-white shadow-xl rounded-2xl p-6 max-w-md w-full mb-6 text-center">
      <img
        src="https://via.placeholder.com/150"
        alt="Anna"
        className="mx-auto rounded-full w-32 h-32 object-cover mb-4"
      />
      <h2 className="text-xl font-semibold">Anna, 28</h2>
      <p className="text-gray-600">Eläinlääkäri Helsingistä</p>
      <p className="mt-2 text-sm text-gray-500 italic">"Elämä on lyhyt — flirttailu tekee siitä pidemmän."</p>
    </div>
  );
}
