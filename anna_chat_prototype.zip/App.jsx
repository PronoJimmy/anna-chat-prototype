import React from "react";
import ChatWindow from "./components/ChatWindow";
import ProfileCard from "./components/ProfileCard";

export default function App() {
  return (
    <div className="min-h-screen bg-pink-50 flex flex-col items-center p-4">
      <ProfileCard />
      <ChatWindow />
    </div>
  );
}
